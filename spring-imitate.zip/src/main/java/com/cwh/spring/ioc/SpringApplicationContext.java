package com.cwh.spring.ioc;

import com.cwh.spring.annotation.Component;
import com.cwh.spring.annotation.ComponentScan;
import com.cwh.spring.annotation.Scope;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;

public class SpringApplicationContext {
    private Class configClass;
    //存放BeanDefinition对象
    // 先把 有 Bean注解的类 生成 BeanDefinition对象，再放入beanDefinitionMap
   private ConcurrentHashMap<String, BeanDefinition> beanDefinitionMap = new ConcurrentHashMap<>();
    //存放单例对象
    private ConcurrentHashMap<String, Object> singletonObjects = new ConcurrentHashMap<>();


    public SpringApplicationContext(Class configClass) {
        beanDefinitionByScan(configClass);

        //将Scope是singleton(默认)的放到singletonObjects
        Enumeration<String> keys = beanDefinitionMap.keys();
        while (keys.hasMoreElements()) {
            String beanName = keys.nextElement();
            BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
            if("singleton".equalsIgnoreCase(beanDefinition.getScope())) {
                //将该bean实例放入到singletonObjects 集合
                Object bean = createBean(beanDefinition);
                singletonObjects.put(beanName, bean);
            }
        }

        //System.out.println("single:" + singletonObjects);
        //System.out.println("map:" + beanDefinitionMap);
    }



    //扫描指定包，创建BeanDefinition对象，并放入Map
    private void beanDefinitionByScan(Class configClass) {
        this.configClass = configClass;
        ComponentScan componentScan =
                (ComponentScan) this.configClass.getDeclaredAnnotation(ComponentScan.class);
        String path = componentScan.value(); //得到要扫描的包
        System.out.println("path:" + path);

        //得到类加载器
        ClassLoader classLoader = SpringApplicationContext.class.getClassLoader();

        path = path.replace(".", "/");
        URL resource = classLoader.getResource(path);
        File file = new File(resource.getFile());

        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                String absolutePath = f.getAbsolutePath();
                if (absolutePath.endsWith(".class")) {
                    String className = absolutePath.substring(
                            absolutePath.lastIndexOf("\\") + 1,
                            absolutePath.lastIndexOf(".class"));
                    String classFullName = path.replace("/", ".") + "." + className;

                    try {
                        Class<?> aClass = classLoader.loadClass(classFullName);
                        //如果该类使用了@Component, 说明是Spring bean
                        if (aClass.isAnnotationPresent(Component.class)) {
                            System.out.println("可以加载到容器：" + className);

                            //得到beanName
                            Component component = aClass.getDeclaredAnnotation(Component.class);
                            String beanName = component.value();
                            //value可以没有设置，是默认值 "", 需要再处理一下
                            if ("".equalsIgnoreCase(beanName)) {
                                // 类名首字母小写作为key, 放入map
                                beanName = StringUtils.uncapitalize(className);
                            }
                            BeanDefinition beanDefinition = new BeanDefinition();
                            beanDefinition.setClazz(aClass);
                            if (aClass.isAnnotationPresent(Scope.class)) {
                                //如果配置了Scope, 获取他配置的值
                                Scope scope = aClass.getDeclaredAnnotation(Scope.class);
                                beanDefinition.setScope(scope.value());
                            } else {
                                //如果没有配置Scope, 就用默认的值singleton
                                beanDefinition.setScope("singleton");
                            }
                            //将beanDefinition 对象放入到Map
                            beanDefinitionMap.put(beanName, beanDefinition);
                        } else {
                            System.out.println("不可以加载到容器：" + className);
                        }
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    //完成createBean，因为map中还是BeanDefinition对象
    private Object createBean(BeanDefinition beanDefinition) {
        Class clazz = beanDefinition.getClazz();
        try {
            Object instance = clazz.getDeclaredConstructor().newInstance();
            return instance;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        //反射创建对象失败
        return null;
    }


    //编写方法返回容器中的对象
    public Object getBean(String name) {
        if (beanDefinitionMap.containsKey(name)) {
            BeanDefinition beanDefinition = beanDefinitionMap.get(name);
            if ("singleton".equalsIgnoreCase(beanDefinition.getScope())) {
                return singletonObjects.get(name); //在单例map中获取
            } else {
                return createBean(beanDefinition);
            }
        } else {
            throw new NullPointerException("没有该bean");
        }
    }
}
