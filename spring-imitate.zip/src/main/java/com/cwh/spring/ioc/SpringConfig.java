package com.cwh.spring.ioc;

import com.cwh.spring.annotation.ComponentScan;

@ComponentScan(value = "com.cwh.spring.component")
public class SpringConfig {
}
