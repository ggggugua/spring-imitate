package com.cwh.spring.component;

import com.cwh.spring.annotation.Component;

@Component
public class MonsterDao {
}
