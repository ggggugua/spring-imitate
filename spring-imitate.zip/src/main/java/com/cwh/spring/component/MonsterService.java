package com.cwh.spring.component;

import com.cwh.spring.annotation.Component;
import com.cwh.spring.annotation.Scope;

@Component(value = "monsterService")
@Scope(value = "prototype")
public class MonsterService {
}
