package com.cwh.spring;

import com.cwh.spring.component.MonsterDao;
import com.cwh.spring.component.MonsterService;
import com.cwh.spring.ioc.SpringApplicationContext;
import com.cwh.spring.ioc.SpringConfig;

public class TestSpring {
    public static void main(String[] args) {
        SpringApplicationContext ioc = new SpringApplicationContext(SpringConfig.class);

        MonsterService monsterService = (MonsterService) ioc.getBean("monsterService");
        MonsterService monsterService2 = (MonsterService) ioc.getBean("monsterService");
        System.out.println("monsterService:" + monsterService);
        System.out.println("monsterService2:" + monsterService2);

        MonsterDao monsterDao = (MonsterDao) ioc.getBean("monsterDao");
        MonsterDao monsterDao2 = (MonsterDao) ioc.getBean("monsterDao");
        System.out.println("monsterDao:" + monsterDao);
        System.out.println("monsterDao2:" + monsterDao2);
        System.out.println("ok");
    }
}
